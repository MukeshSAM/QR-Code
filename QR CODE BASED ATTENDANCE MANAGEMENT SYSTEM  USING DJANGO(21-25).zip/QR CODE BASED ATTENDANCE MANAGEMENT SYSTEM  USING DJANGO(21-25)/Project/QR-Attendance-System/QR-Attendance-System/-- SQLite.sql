SELECT*FROM FacultyView_student;
